# WRA410-Assignment-5/6

Auden Rein + Sumaiya Asghar

Drawing on canvas app: We plan to create a Javascript application that will let users draw on a blank canvas. The canvas will be part of a web page that lets users select the color of their pen, and size of the stroke.

Project Overview: The drawing app will have a few separate components. The main part of the app is the canvas. The canvas will be a defined area that accepts a listener that checks to see if the mouse is pressed and at what location. The program will need to take in the location of the pressed mouse and output a color so that it ‘draws’ on the canvas. There will be a few controlling elements as well such as color of the pen, size of the pen, and the ability to erase the canvas. 

Auden: 
  Will be responsible for:
    Coding the HTML structure of the application.
    The CSS for the control panel of the pen tool. 
    Coding the Javascript for the pen tool.

Sumaiya: 
  Will be responsible for:
    CSS for the canvas.
    Planning of the Javascript.
    Coding the Javascript for the canvas and the logic for clearing the screen.
